//INSIBLLE MONKEY AND SCORE!!!!
var bananaImage, player, ground;
var obstacleImage;
var backImage,player_running,score;
var foodGroup;
var obstacleGroup;

function preload()
{
 backImage=loadImage("jungle.jpg");
 player_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
 bananaImage=loadImage("banana.png");
 obstacleImage=loadImage("stone.png");
} 

function setup() 
{
  createCanvas(400, 400);
  player= createSprite(50,380,20,20);
  player.addAnimation("monkey",player_running);
  player.scale=0.15;
  player.visible=true;

  ground=createSprite(200,380,800,20);
  ground.x = ground.width /2;
  ground.velocityX = -4;
  
  background1=createSprite(200,200,200,200);
  background1.addAnimation("backImage",backImage);
  
  foodGroup=new Group();
  obstacleGroup=new Group();
  
  score=0;
}

function draw() 
{
  background("white");
  
  if(keyDown("space")&& player.y >= 200 )
    {
      player.velocityY = -12 ;
    }

  player.velocityY = player.velocityY + 0.8;

   if (ground.x < 0)
   { 
      ground.x = ground.width/2;
    }
  
  spawnFood();
  
  spawnObstacles();
  
  if(foodGroup.isTouching(player))
  {
    score = score+2;
    foodGroup.destroyEach();
  }
  switch(score)
    {
      case 10:player.scale=0.12;
      break;
      case 20:player.scale=0.14;
      break;
      case 30:player.scale=0.16;
      break;
      case 40:player.scale=0.18;
      break;
      default: break;
    }
   
  if(obstacleGroup.isTouching(player))
  {
   player.scale=0.10; 
  } 
  
  player.collide(ground); 

  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500,50);
  
}

function spawnFood()
{
  //spawn bananas
  if(frameCount % 80 === 0) 
  {
    //create banana
    var banana = createSprite(400,365,10,40);
    
    //assign banana velocity
    banana.velocityX=-3;
    
    //generate random bananas
    var rand= Math.round(random(250,300));
    banana.addImage("banana",bananaImage);
    banana.y=rand;

    //assign scale and lifetime to the bananas          
    banana.scale = 0.05;
    banana.lifetime = 300;
    
    //add each banana to the banana group
    foodGroup.add(banana);
  }
}

function spawnObstacles()
{
  //spawn stones
  if (frameCount % 150 === 0) 
  {
    //create stone
    var stone = createSprite(400,370,40,10);
    
    //assign stone velocity
    stone.velocityX = -3;
    
    //set stone animation
    stone.addImage("stone",obstacleImage);

     //assign scale and lifetime to the stone
    stone.lifetime = 150;
    stone.scale=0.05;
    
    //add each stone to the obstacle group
    obstacleGroup.add(stone);
  }
}








  